import java.util.List;
import java.util.ArrayList;

/**
 * La clase SpiralPath representa un camino en forma de espiral dibujado en el canvas.
 * 
 * Esta clase crea y gestiona una espiral visual compuesta por segmentos rectangulares
 * que alternan entre orientación horizontal y vertical. La espiral se dibuja desde
 * un punto de origen y disminuye gradualmente de tamaño con cada segmento.
 * 
 * Los segmentos horizontales se dibujan en azul y los verticales en rojo,
 * creando un patrón visual distintivo que simula un camino espiral.
 * 
 * @author MorenoRubiano
 * @version 2.0
 */
public class SpiralPath {
    /** Longitud actual de la espiral (número de segmentos) */
    private int length;
    
    /** Tamaño de la unidad en píxeles (no utilizado en implementación actual) */          
    private int unitPx;
    
    /** Coordenada X del punto de origen de la espiral */          
    private int originX;
    
    /** Coordenada Y del punto de origen de la espiral */         
    private int originY;
    
    /** Grosor de cada segmento de la espiral */         
    private int thickness;
    
    /** Referencia al canvas donde se dibuja la espiral */
    private Canvas canvas;
    
    /** Estado de visibilidad de la espiral */
    private boolean visible;
    
    /** Indica si la funcionalidad de espiral está habilitada */
    private boolean spiralEnabled;
    
    /** Lista de rectángulos que forman los segmentos de la espiral */
    private final List<Rectangle> segments;
    
    /** Porcentaje de reducción del ancho en cada iteración (90%) */
    private float W_PERCENTAJE_DECRECE = 0.9f;
    
    /** Porcentaje de reducción de la altura en cada iteración (80%) */
    private float H_PERCENTAJE_DECRECE = 0.8f;

    /**
     * Constructor de la clase SpiralPath.
     * 
     * Inicializa una nueva espiral con un punto de origen específico y un grosor
     * determinado para los segmentos. La espiral se crea inicialmente invisible
     * y sin segmentos calculados.
     * 
     * @param originX La coordenada X del punto de inicio de la espiral
     * @param originY La coordenada Y del punto de inicio de la espiral
     * @param thickness El grosor en píxeles de cada segmento de la espiral
     */
    public SpiralPath(int originX, int originY, int thickness) {
        this.canvas = Canvas.getCanvas();
        this.originX = originX;
        this.originY = originY;
        this.thickness = thickness;
        this.visible = false;
        this.spiralEnabled = false;
        this.segments = new ArrayList<>();
    }

    /**
     * Hace visible la espiral en el canvas.
     * 
     * Si la espiral no está visible, cambia su estado a visible y
     * dibuja todos los segmentos que componen la espiral.
     */
    public void makeVisible() {
        if (visible) return;
        visible = true;
        draw();
    }

    /**
     * Hace invisible la espiral en el canvas.
     * 
     * Si la espiral está visible, borra todos los segmentos del canvas
     * y cambia su estado a invisible.
     */
    public void makeInvisible() {
        if (!visible) return;
        erase();
        visible = false;
    }

    /**
     * Dibuja todos los segmentos de la espiral en el canvas.
     * 
     * Método privado que hace visible cada rectángulo que forma
     * parte de la espiral si la espiral está en estado visible.
     */
    private void draw() {
        if (visible) {
            for (Rectangle rect : segments) {
                rect.makeVisible();
            }
        }
    }

    /**
     * Borra todos los segmentos de la espiral del canvas.
     * 
     * Método privado que hace invisible cada rectángulo que forma
     * parte de la espiral, ocultándola completamente del canvas.
     */
    private void erase() {
        for (Rectangle rect : segments) {
            rect.makeInvisible();
        }
    }

    /**
     * Redibuja la espiral completa en el canvas.
     * 
     * Si la espiral está visible, primero la borra completamente
     * y luego la vuelve a dibujar. Útil para actualizar la
     * visualización después de cambios en la estructura.
     */
    public void redraw() {
        if (visible) {
            erase();
            draw();
        }
    }

    /**
     * Verifica si la espiral está visible en el canvas.
     * 
     * @return true si la espiral está visible, false en caso contrario
     */
    public boolean isVisible() { 
        return visible;
    }

    /**
     * Calcula y genera una espiral con la longitud especificada.
     * 
     * Este método es el núcleo de la funcionalidad de la espiral. Calcula
     * la posición, tamaño y orientación de cada segmento para crear un
     * patrón espiral que se reduce gradualmente.
     * 
     * La espiral alterna entre segmentos horizontales (azules) y verticales (rojos),
     * comenzando horizontalmente. Cada segmento es más pequeño que el anterior
     * según los porcentajes de reducción establecidos.
     * 
     * El proceso se detiene cuando se alcanza la longitud deseada o cuando
     * los segmentos se vuelven demasiado pequeños (menores a los mínimos establecidos).
     * 
     * @param length El número máximo de segmentos que debe tener la espiral
     */
    public void calcSpiral(int length) {
        final int wCanvas = this.canvas.CANVAS_WIDTH;
        final int hCanvas = this.canvas.CANVAS_HEIGHT;
        final float minWidthPx = 35f;
        final float minHeightPx = 30f;

        // Reset de segmentos - limpia la espiral anterior
        segments.clear();

        // Tamaños iniciales basados en las dimensiones del canvas
        float currentW = wCanvas * W_PERCENTAJE_DECRECE;
        float currentH = hCanvas * H_PERCENTAJE_DECRECE;

        // Puntos de inicio desde el origen establecido
        int x = originX;
        int y = originY;

        // Dirección intercalada: true = horizontal, false = vertical
        boolean horizontal = true;

        for (int i = 0; i < length; i++) {
            // Verificar si los segmentos son demasiado pequeños para continuar
            if (currentW < minWidthPx || currentH < minHeightPx) break;

            int width, height;

            if (horizontal) {
                // Segmento horizontal (azul)
                width = (int) currentW;
                height = thickness;
                Rectangle rect = new Rectangle(
                    height,
                    width,
                    x,
                    y,
                    "blue"
                );
                segments.add(rect);
                x += width; // Mover el punto de inicio horizontalmente
            } else {
                // Segmento vertical (rojo)
                width = thickness;
                height = (int) currentH;
                Rectangle rect = new Rectangle(
                    height,
                    width,
                    x,
                    y,
                    "red"
                );
                segments.add(rect);
                y += height; // Mover el punto de inicio verticalmente
            }

            // Reducir dimensiones para el siguiente segmento
            currentW *= W_PERCENTAJE_DECRECE;
            currentH *= H_PERCENTAJE_DECRECE;

            // Alternar entre horizontal y vertical
            horizontal = !horizontal;
        }

        // Actualizar la longitud real de la espiral generada
        this.length = segments.size();

        // Si ya estaba visible, redibujar la nueva espiral
        if (visible) {
            redraw();
        }
    }
}
