/**
 * La clase ProfitBar representa una barra de progreso visual que muestra
 * el progreso actual de las ganancias o beneficios en relación con un máximo establecido.
 * 
 * La barra está compuesta por dos rectángulos:
 * - Un rectángulo de fondo (gris) que representa el máximo posible
 * - Un rectángulo de progreso (verde) que representa el valor actual
 * 
 * @author MorenoRubiano
 * @version 2.1
 */
public class ProfitBar {
    private int xPosition;
    private int yPosition;
    private int maxProfit;
    private int currentProfit;
    private boolean visible;
    
    private Rectangle backgroundBar;  // Barra de fondo
    private Rectangle progressBar;    // Barra de progreso

    private static final int BAR_WIDTH = 200;
    private static final int BAR_HEIGHT = 20;

    /**
     * Constructor de ProfitBar
     * @param x posición X en el canvas
     * @param y posición Y en el canvas  
     * @param maxProfit valor máximo de profit
     */
    public ProfitBar(int x, int y, int maxProfit) {
        this.xPosition = x;
        this.yPosition = y;
        this.maxProfit = Math.max(1, maxProfit); // Evitar división por cero
        this.currentProfit = 0;
        this.visible = false;
        
        // Crear rectángulo de fondo (gris)
        this.backgroundBar = new Rectangle(
            BAR_HEIGHT,           // height
            BAR_WIDTH,            // width  
            xPosition,            // xPosition
            yPosition,            // yPosition
            "black"               // color de fondo
        );
        
        // Crear rectángulo de progreso (verde)
        this.progressBar = new Rectangle(
            BAR_HEIGHT,           // height
            0,                    // width inicial = 0
            xPosition,            // xPosition
            yPosition,            // yPosition
            "green"               // color de progreso
        );
    }

    /**
     * Hace visible la barra de progreso
     */
    public void makeVisible() {
        if (!visible) {
            visible = true;
            backgroundBar.makeVisible();
            updateProgressBar();
        }
    }

    /**
     * Hace invisible la barra de progreso
     */
    public void makeInvisible() {
        if (visible) {
            visible = false;
            backgroundBar.makeInvisible();
            progressBar.makeInvisible();
        }
    }

    /**
     * Actualiza los valores de la barra de progreso
     * @param current valor actual de profit
     * @param maxPossible nuevo valor máximo posible
     */
    public void updateProfitBar(int current, int maxPossible) {
        this.currentProfit = Math.max(0, current);
        this.maxProfit = Math.max(1, maxPossible); // Evitar división por cero
        
        if (visible) {
            updateProgressBar();
        }
    }

    /**
     * Obtiene el valor actual de profit
     * @return valor actual de profit
     */
    public int getCurrent() {
        return currentProfit;
    }

    /**
     * Resetea la barra de progreso a 0
     */
    public void reset() {
        this.currentProfit = 0;
        if (visible) {
            updateProgressBar();
        }
    }

    /**
     * Actualiza visualmente la barra de progreso
     */
    private void updateProgressBar() {
        if (!visible) return;
        
        // Calcular nuevo ancho basado en el porcentaje de progreso
        double percentage = (double) currentProfit / maxProfit;
        percentage = Math.min(1.0, Math.max(0.0, percentage)); // Clamping entre 0 y 1
        
        int newWidth = (int) (BAR_WIDTH * percentage);
        
        // Ocultar barra anterior si existe
        progressBar.makeInvisible();
        
        // Actualizar tamaño y mostrar nueva barra
        progressBar.changeSize(BAR_HEIGHT, newWidth);
        progressBar.makeVisible();
    }

    /**
     * Verifica si la barra está visible
     * @return true si está visible, false en caso contrario
     */
    public boolean isVisible() {
        return visible;
    }
    
    /**
     * Obtiene el valor máximo de profit
     * @return valor máximo de profit
     */
    public int getMaxProfit() {
        return maxProfit;
    }
}