import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.ArrayList;

/**
 * La clase SilkRoad representa el juego principal de la Ruta de la Seda.
 * 
 * Esta clase actúa como el controlador principal del juego, gestionando:
 * - Las tiendas distribuidas a lo largo de la ruta
 * - Los robots que viajan y recolectan tenges
 * - La barra de progreso que muestra las ganancias
 * - Las soluciones y abstracciones del juego
 * 
 * El juego simula el comercio en la histórica Ruta de la Seda, donde
 * los robots representan comerciantes que viajan entre tiendas para
 * maximizar sus ganancias recolectando tenges (moneda del juego).
 * 
 * @author MorenoRubiano
 * @version 2.0
 */
public class SilkRoad {

    /** Mapa de tiendas organizadas por ubicación */
    private final Map<Integer, Store> stores;
    
    /** Lista de robots que participan en el juego */
    private final ArrayList<Robot> robots;

    private final SpiralPath spiralPath;
    
    /** Mapa que relaciona robots con tiendas para abstraer soluciones */
    private final HashMap<Robot, Store> solutionAbstraction;
    
    /** Barra de progreso visual que muestra las ganancias del juego */
    private final ProfitBar profitBar;

    private boolean lastActionSuccess = true;

    /**
     * Constructor del ciclo 1 - Inicializa el juego con una longitud específica.
     * 
     * Crea una nueva instancia del juego SilkRoad con las estructuras de datos
     * necesarias y configura la barra de progreso basada en la longitud proporcionada.
     * El máximo de la barra de progreso se calcula como longitud * 100.
     * 
     * @param lenght La longitud del recorrido que determina el máximo de ganancias posibles
     */
    public SilkRoad(int lenght){
        this.stores = new TreeMap<>(); 
        this.robots = new ArrayList<>();
        this.solutionAbstraction = new HashMap<>();
        this.spiralPath = new SpiralPath(20, 20, 20);
        this.profitBar = new ProfitBar(300, 300, lenght*100);
        
    }
    
    /**
     * Constructor del ciclo 2 - Inicializa el juego con una matriz de días.
     * 
     * Crea una nueva instancia del juego SilkRoad para escenarios multi-día.
     * La barra de progreso se configura basada en el número de columnas de la
     * matriz de días multiplicado por 100.
     * 
     * @param days Matriz bidimensional que representa los días del juego
     */
    public SilkRoad(int[][] days){
        this.stores = new TreeMap<>();
        this.robots = new ArrayList<>();
        this.spiralPath = null;
        this.solutionAbstraction = new HashMap<>();
        this.profitBar = new ProfitBar(300, 300, days[0].length*100);

        
    } 

    public boolean ok(){
        return this.lastActionSuccess;
    }
    /**
     * Coloca una nueva tienda en una ubicación específica con una cantidad inicial de tenges.
     * 
     * Crea una nueva instancia de Store con la posición y cantidad de tenges especificadas,
     * y la agrega al mapa de tiendas usando la ubicación como clave.
     * 
     * @param location La posición donde se ubicará la tienda
     * @param tenges La cantidad inicial de tenges que contendrá la tienda
     */
    public void placeStore(int location,int tenges){
        if (this.stores.containsKey(location)) {
        this.lastActionSuccess = false;
        return;
    }
        Store store = new Store(location, tenges);
        this.stores.put(location, store);
        this.lastActionSuccess = true;

    }

    /**
     * Elimina una tienda de la ubicación especificada.
     * 
     * Remueve la tienda del mapa de tiendas utilizando la ubicación como clave.
     * Si no existe una tienda en esa ubicación, el método no realiza ninguna acción.
     * 
     * @param location La posición de la tienda que se desea eliminar
     */
    public void removeStore(int location){
        if (!this.stores.containsKey(location)) {
            this.lastActionSuccess = false;
            return;
        }
        this.stores.remove(location);
        this.lastActionSuccess = true;
    }
    /**
     * Coloca un nuevo robot en una ubicación específica.
     * 
     * Crea una nueva instancia de Robot con la posición especificada y lo agrega
     * a la lista de robots. El parámetro tenges no se utiliza en la implementación actual.
     * 
     * @param location La posición inicial donde se ubicará el robot
     * @param tenges Parámetro no utilizado en la implementación actual
     */
    public void placeRobot(int location, int tenges){
        Robot robot = new Robot(location);
        this.robots.add(robot);
    }

    /**
     * Elimina un robot de la ubicación especificada.
     * 
     * Busca un robot en la posición indicada y, si lo encuentra, lo remueve
     * de la lista de robots. Si no hay ningún robot en esa ubicación,
     * no realiza ninguna acción.
     * 
     * @param location La posición del robot que se desea eliminar
     */
    public void removeRobot(int location){
        Robot robot = findRobotAtLocation(location);
        if (robot != null) {
            this.robots.remove(robot);
        }

    }


    /**
     * Busca un robot en la posición especificada.
     * 
     * Recorre la lista de robots para encontrar uno que esté ubicado
     * en la posición especificada.
     * 
     * @param location La posición en la que se busca el robot
     * @return El robot encontrado en esa posición, o null si no hay ninguno
     */
    private Robot findRobotAtLocation(int location) {
        for (Robot robot : this.robots) {
            if (robot.getPosition() == location) {
                return robot;
            }
        }
        return null;
    }

    /**
     * Mueve un robot desde su ubicación actual una cantidad específica de metros.
     * 
     * Busca el robot en la ubicación especificada y lo mueve la cantidad de metros
     * indicada. Si no hay robot en esa ubicación o si los metros son <= 0,
     * no realiza ninguna acción.
     * 
     * @param location La ubicación actual del robot que se desea mover
     * @param meters La cantidad de metros que el robot debe avanzar
     */
    /**
     * Mueve un robot desde su ubicación actual una cantidad específica de metros.
     * 
     * Busca el robot en la ubicación especificada y lo mueve la cantidad de metros
     * indicada. Si no hay robot en esa ubicación o si los metros son <= 0,
     * no realiza ninguna acción.
     * 
     * @param location La ubicación actual del robot que se desea mover
     * @param meters La cantidad de metros que el robot debe avanzar
     */
    public void moveRobot(int location, int meters) {
        if (meters <= 0) {
            return;
        }

        Robot robot = findRobotAtLocation(location);
        if (robot == null) {
            return;
        }
    
        int newPosition = location + meters;
        robot.moveTo(newPosition);
    }
    
    /**
     * Reabastece todas las tiendas del juego.
     * 
     * Recorre todas las tiendas en el mapa y las reabastece a su cantidad
     * inicial de tenges, restaurando el estado original de cada tienda.
     */
    public void resupplyStores() {
        for (Store store : this.stores.values()) {
            store.resupply();
        }
    }

    /**
     * Regresa todos los robots a sus posiciones iniciales.
     * 
     * Recorre todos los robots y los mueve de vuelta a sus ubicaciones
     * iniciales establecidas durante su creación.
     */
    public void returnRobots() {
    for (Robot robot : this.robots) {
        robot.goInitialPosition();
    }
    }

    /**
     * Reinicia completamente el estado del juego.
     * 
     * Este método restaura el juego a su estado inicial:
     * - Regresa todos los robots a sus posiciones iniciales
     * - Establece las ganancias de todos los robots a 0
     * - Limpia el mapa de abstracción de soluciones
     * - Resetea la barra de progreso
     */
    public void reboot(){
        for (Robot robot : this.robots) {
            robot.goInitialPosition();
            robot.pickTenges(0);
        }
        this.solutionAbstraction.clear();
        this.profitBar.reset();
        
    }
    
    /**
     * Obtiene el valor actual de la barra de progreso.
     * 
     * @return El valor actual de progreso de la barra de ganancias
     */
    public int profitBar(){
        return this.profitBar.getCurrent();

    }

    /**
     * Calcula el total de ganancias de todos los robots.
     * 
     * Suma las ganancias (tenges) de todos los robots en el juego
     * para obtener el profit total acumulado.
     * 
     * @return La suma total de ganancias de todos los robots
     */
    public int totalProfit(){
        int total = 0;
        for (Robot robot : this.robots) {
            total += robot.getProfit();
        }
        return total;
    }

    /**
     * Actualiza la barra de progreso con los valores de profit actuales.
     * 
     * Delega la actualización visual de la barra de progreso al objeto ProfitBar,
     * pasando los valores de profit actual y máximo posible.
     * 
     * @param currentProfit El profit actual obtenido
     * @param maxPossibleProfit El máximo profit posible en el juego
     */
    public void updateProFitBar(int currentProfit, int maxPossibleProfit){
    this.profitBar.updateProfitBar(currentProfit, maxPossibleProfit);
    }

    /**
     * Obtiene información de todas las tiendas en formato de matriz.
     * 
     * Crea una matriz bidimensional donde cada fila representa una tienda
     * y las columnas contienen la ubicación y la cantidad de tenges respectivamente.
     * 
     * @return Matriz int[][] donde [i][0] es la ubicación y [i][1] es la cantidad de tenges
     */
    public int[][] stores() {
        int[][] result = new int[this.stores.size()][2];
        int i = 0;
    
        for (Store store : this.stores.values()) {
            result[i][0] = store.getLocation();
            result[i][1] = store.getTenges();
            i++;
        }
    
    return result;
}

/**
 * Obtiene información de todos los robots en formato de matriz ordenada.
 * 
 * Crea una matriz bidimensional donde cada fila representa un robot
 * y las columnas contienen la posición y las ganancias respectivamente.
 * Los robots se ordenan por posición antes de generar la matriz.
 * 
 * @return Matriz int[][] donde [i][0] es la posición y [i][1] son las ganancias del robot
 */
public int[][] robots() {
    int[][] result = new int[this.robots.size()][2];
    
    this.robots.sort((r1, r2) -> Integer.compare(r1.getPosition(), r2.getPosition()));
    
    for (int i = 0; i < this.robots.size(); i++) {
        Robot robot = this.robots.get(i);
        result[i][0] = robot.getPosition();
        result[i][1] = robot.getProfit();
    }
    
    return result;
}

public void showSpiral(int length) {
    if (spiralPath != null) {
        spiralPath.calcSpiral(length);
        spiralPath.makeVisible();
    }
}

public void hideSpiral() {
    if (spiralPath != null) {
        spiralPath.makeInvisible();
    }
}

public void showProfitBar() {
    profitBar.makeVisible();
}

public void hideProfitBar() {
    profitBar.makeInvisible();
}


}



