/**
 * La clase Store representa una tienda o almacén en el juego Silk Road.
 * 
 * Cada tienda tiene una ubicación específica en el mapa y contiene una cantidad
 * de tenges (moneda del juego). Las tiendas pueden estar vacías o llenas,
 * visibles o invisibles, y pueden ser reabastecidas o vaciadas según las
 * mecánicas del juego.
 * 
 * La tienda mantiene tanto la cantidad inicial de tenges (para reabastecimiento)
 * como la cantidad actual disponible para el jugador.
 * 
 * @author MorenoRubiano
 * @version 2.0
 */
public class Store {
    /** Ubicación actual de la tienda en el mapa */
    private int location;
    
    /** Color asociado a la tienda (por defecto "yellow") */
    private String color;
    
    /** Estado de visibilidad de la tienda en el canvas */
    private boolean isVisible;
    
    /** Indica si la tienda está vacía (sin tenges) */
    private boolean isEmpty;
    
    /** Cantidad inicial de tenges que tenía la tienda al ser creada */
    private int initialTenges;
    
    /** Cantidad actual de tenges disponibles en la tienda */
    private int actualTenges;
    
    /** Ubicación inicial de la tienda (inmutable) */
    private final int initialLocation;

    /**
     * Constructor de la clase Store.
     * 
     * Crea una nueva tienda en una ubicación específica con una cantidad inicial de tenges.
     * La tienda se inicializa como invisible y su estado de vacío depende de la cantidad
     * inicial de tenges proporcionada.
     * 
     * @param location La posición donde se ubicará la tienda en el mapa
     * @param initialTenges La cantidad inicial de tenges que contendrá la tienda
     */
    public Store(int location,int initialTenges) {
        this.location = location;
        this.color = "yellow";
        this.isVisible = false;
        this.isEmpty = (initialTenges <= 0);
        this.initialTenges = initialTenges;
        this.actualTenges = this.initialTenges;
        this.initialLocation = location;
        this.isVisible = false;
    }

    /**
     * Reabastece la tienda restaurando su cantidad inicial de tenges.
     * 
     * Este método restablece la cantidad actual de tenges al valor inicial
     * que tenía la tienda cuando fue creada, y actualiza el estado de vacío
     * en consecuencia.
     */
    public void resupply() {
        this.actualTenges = this.initialTenges;
        this.isEmpty = (this.actualTenges == 0);
    }

    /**
     * Vacía completamente la tienda y retorna la cantidad de tenges que contenía.
     * 
     * Este método establece la cantidad actual de tenges a 0, marca la tienda
     * como vacía, y devuelve la cantidad de tenges que tenía antes de ser vaciada.
     * 
     * @return La cantidad de tenges que contenía la tienda antes de ser vaciada
     */
    public int emptyStore(){
        int temp = this.actualTenges;
        this.actualTenges = 0;
        this.isEmpty = (this.actualTenges == 0);
        return temp;
    }

    /**
     * Hace visible la tienda en el canvas del juego.
     * 
     * Cambia el estado de visibilidad de la tienda a verdadero,
     * permitiendo que sea mostrada en la interfaz gráfica.
     */
    public void makeVisible() {
        this.isVisible = true;
    }

    /**
     * Configura la tienda con una nueva ubicación y cantidad inicial de tenges.
     * 
     * Este método permite reconfigurar una tienda existente estableciendo
     * una nueva posición y cantidad de tenges. La cantidad se asegura de ser
     * no negativa, y se actualizan todos los valores relacionados.
     * 
     * @param location La nueva ubicación de la tienda en el mapa
     * @param initialTenges La nueva cantidad inicial de tenges (se asegura ≥ 0)
     * @return La cantidad actual de tenges después de la configuración
     */
    public int set(int location, int initialTenges) {
        this.location = location;
        this.initialTenges = Math.max(0, initialTenges);
        this.actualTenges = this.initialTenges;
        this.isEmpty = (this.actualTenges == 0);
        return this.actualTenges;
    }

    /**
     * Hace invisible la tienda en el canvas del juego.
     * 
     * Cambia el estado de visibilidad de la tienda a falso,
     * ocultándola de la interfaz gráfica.
     */
    public void makeInvisible() {
        this.isVisible = false;
    }

    /**
     * Verifica si la tienda está vacía.
     * 
     * @return true si la tienda no tiene tenges (actualTenges == 0), false en caso contrario
     */
    public boolean isEmpty() {
        return (this.actualTenges == 0);
    }

    public int getLocation() {
        return location;
    }

    public int getTenges() {
        return actualTenges;
    }

}
